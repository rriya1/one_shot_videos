---
name: Support
about: Request some help with using this package

---

<!-- Requirements: please go through this checklist before opening a new issue -->
  - [ ] Review the documentation: https://github.com/oblador/react-native-vector-icons
  - [ ] Search for existing issues (including closed ones): https://github.com/oblador/react-native-vector-icons/issues

<!-- Describe your environment (OS, target platform, react-native-vector-icons version etc.) -->
## Environment

<!-- Describe what you want to do and what you have tried. -->
## Description
Describe your issue in detail. Include screenshots if needed.

## Demo
You can use https://snack.expo.io/ to create a demo that can help users to better understand your problem.
